-- 1. Eliminamos tablas si existen

DROP DATABASE IF EXISTS repaso;
CREATE DATABASE repaso; 
USE repaso; 

-- 2. Creamos las tablas

CREATE TABLE cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100) UNIQUE
);

CREATE TABLE producto (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    precio DECIMAL(8,2),
    stock INT
);

CREATE TABLE pedido (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    fecha DATE,
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

CREATE TABLE detalle_pedido (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    id_producto INT,
    cantidad INT,
    FOREIGN KEY (id_pedido) REFERENCES pedido(id_pedido),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
);

-- 3. Insertamos clientes
INSERT INTO cliente (nombre, email) VALUES 
('Laura Pérez', 'laura.perez@email.com'),
('Carlos Ruiz', 'carlos.ruiz@email.com'),
('Ana Gómez', 'ana.gomez@email.com'),
('Luis Martínez', 'luis.martinez@email.com');

-- 4. Insertamos productos
INSERT INTO producto (nombre, precio, stock) VALUES 
('Ratón inalámbrico', 15.90, 50),
('Teclado mecánico', 55.00, 25),
('Monitor 24"', 120.00, 10),
('Memoria USB 32GB', 7.50, 100),
('Auriculares Bluetooth', 30.00, 40);

-- 5. Insertamos pedidos
INSERT INTO pedido (id_cliente, fecha) VALUES 
(1, '2025-01-10'),
(1, '2025-03-05'),
(2, '2025-01-12'),
(3, '2025-04-15');

-- 6. Insertamos detalles de pedidos
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad) VALUES 
(1, 1, 2), -- Laura compra 2 ratones
(1, 2, 1), -- Laura compra 1 teclado
(2, 4, 3), -- Laura compra 3 USBs en otro pedido
(3, 3, 1), -- Carlos compra un monitor
(3, 5, 1), -- Carlos compra unos auriculares
(4, 2, 1); -- Ana compra 1 teclado
